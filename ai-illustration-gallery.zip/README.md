# AI Illustration Gallery

## ローカルで確認
1. index.htmlをダブルクリック
2. ブラウザで表示を確認
3. 作品画像・タイトル・説明・リンクを編集

## GitHub Pagesで公開
1. GitHubでPublicリポジトリを作成
2. index.htmlをアップロード
3. Settings → Pages
4. Deploy from a branchを選択
5. main / rootを選択してSave

※ 成人向け作品を掲載する場合は、利用するサービス・地域の規約や法令を確認してください。
